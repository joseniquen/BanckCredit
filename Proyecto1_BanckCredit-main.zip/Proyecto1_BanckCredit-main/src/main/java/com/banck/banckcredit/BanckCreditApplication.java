package com.banck.banckcredit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BanckCreditApplication {

	public static void main(String[] args) {
		SpringApplication.run(BanckCreditApplication.class, args);
	}

}
